#!/bin/sh
inkscape -D --export-filename=.\Graphics\uhlogo.pdf --export-latex .\Graphics\uhlogo.svg